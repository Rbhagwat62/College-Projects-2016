﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Register_user
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridUsers = New System.Windows.Forms.DataGridView()
        Me.UsernameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UseridDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContactnumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VehiclenumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VehiclemodelDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RfidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DesignationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UsersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataSetUser = New VehicleParking2016.DataSetUser()
        CType(Me.DataGridUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UsersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSetUser, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridUsers
        '
        Me.DataGridUsers.AutoGenerateColumns = False
        Me.DataGridUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridUsers.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.UsernameDataGridViewTextBoxColumn, Me.UseridDataGridViewTextBoxColumn, Me.ContactnumberDataGridViewTextBoxColumn, Me.VehiclenumberDataGridViewTextBoxColumn, Me.VehiclemodelDataGridViewTextBoxColumn, Me.RfidDataGridViewTextBoxColumn, Me.DesignationDataGridViewTextBoxColumn})
        Me.DataGridUsers.DataSource = Me.UsersBindingSource
        Me.DataGridUsers.Location = New System.Drawing.Point(55, 45)
        Me.DataGridUsers.Name = "DataGridUsers"
        Me.DataGridUsers.Size = New System.Drawing.Size(745, 189)
        Me.DataGridUsers.TabIndex = 0
        '
        'UsernameDataGridViewTextBoxColumn
        '
        Me.UsernameDataGridViewTextBoxColumn.DataPropertyName = "User_name"
        Me.UsernameDataGridViewTextBoxColumn.HeaderText = "User_name"
        Me.UsernameDataGridViewTextBoxColumn.Name = "UsernameDataGridViewTextBoxColumn"
        '
        'UseridDataGridViewTextBoxColumn
        '
        Me.UseridDataGridViewTextBoxColumn.DataPropertyName = "User_id"
        Me.UseridDataGridViewTextBoxColumn.HeaderText = "User_id"
        Me.UseridDataGridViewTextBoxColumn.Name = "UseridDataGridViewTextBoxColumn"
        '
        'ContactnumberDataGridViewTextBoxColumn
        '
        Me.ContactnumberDataGridViewTextBoxColumn.DataPropertyName = "Contact_number"
        Me.ContactnumberDataGridViewTextBoxColumn.HeaderText = "Contact_number"
        Me.ContactnumberDataGridViewTextBoxColumn.Name = "ContactnumberDataGridViewTextBoxColumn"
        '
        'VehiclenumberDataGridViewTextBoxColumn
        '
        Me.VehiclenumberDataGridViewTextBoxColumn.DataPropertyName = "Vehicle_number"
        Me.VehiclenumberDataGridViewTextBoxColumn.HeaderText = "Vehicle_number"
        Me.VehiclenumberDataGridViewTextBoxColumn.Name = "VehiclenumberDataGridViewTextBoxColumn"
        '
        'VehiclemodelDataGridViewTextBoxColumn
        '
        Me.VehiclemodelDataGridViewTextBoxColumn.DataPropertyName = "Vehicle_model"
        Me.VehiclemodelDataGridViewTextBoxColumn.HeaderText = "Vehicle_model"
        Me.VehiclemodelDataGridViewTextBoxColumn.Name = "VehiclemodelDataGridViewTextBoxColumn"
        '
        'RfidDataGridViewTextBoxColumn
        '
        Me.RfidDataGridViewTextBoxColumn.DataPropertyName = "Rf_id"
        Me.RfidDataGridViewTextBoxColumn.HeaderText = "Rf_id"
        Me.RfidDataGridViewTextBoxColumn.Name = "RfidDataGridViewTextBoxColumn"
        '
        'DesignationDataGridViewTextBoxColumn
        '
        Me.DesignationDataGridViewTextBoxColumn.DataPropertyName = "Designation"
        Me.DesignationDataGridViewTextBoxColumn.HeaderText = "Designation"
        Me.DesignationDataGridViewTextBoxColumn.Name = "DesignationDataGridViewTextBoxColumn"
        '
        'UsersBindingSource
        '
        Me.UsersBindingSource.DataMember = "Users"
        Me.UsersBindingSource.DataSource = Me.DataSetUser
        '
        'DataSetUser
        '
        Me.DataSetUser.DataSetName = "DataSetUser"
        Me.DataSetUser.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Register_user
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(856, 246)
        Me.Controls.Add(Me.DataGridUsers)
        Me.Name = "Register_user"
        Me.Text = "Register_user"
        CType(Me.DataGridUsers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UsersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSetUser, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridUsers As System.Windows.Forms.DataGridView
    Friend WithEvents UsernameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UseridDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ContactnumberDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VehiclenumberDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VehiclemodelDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RfidDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DesignationDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UsersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataSetUser As VehicleParking2016.DataSetUser
End Class
