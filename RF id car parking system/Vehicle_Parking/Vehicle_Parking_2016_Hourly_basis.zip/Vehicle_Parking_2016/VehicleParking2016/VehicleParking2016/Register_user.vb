﻿Public Class Register_user

    Private Sub Register_user_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Home.OleDbDataUser.Fill(Home.DataSetUser1)
        Home.OleDbDataUser.Update(Home.DataSetUser1)
        DataGridUsers.DataSource = Home.DataSetUser1.Tables(0)
    End Sub


End Class