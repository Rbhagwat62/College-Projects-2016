﻿Imports System.Text.RegularExpressions

Public Class Registration_Form
    Private NameValid As Boolean
    Private VehicleNameValid As Boolean
    Private DesignationValid As Boolean
    Private MobileValid As Boolean
    Private VehicleNoValid As Boolean


    Private Sub btn_register_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_register.Click
        Dim i As Integer
        Dim user_name, contact_no, vehical_number, vehical_model, designation As String
        Dim rw As DataRow
        If NameValid = False Or MobileValid = False Or VehicleNameValid = False Or VehicleNameValid = False Or DesignationValid = False Then
            MessageBox.Show("All fields are neccessory.")
        Else
            'Add a new row to the Student table.
            'rw = DataRegisterUser1.Tables(0).NewRow
            rw = Home.DataSetUser1().Tables(0).NewRow
            user_name = Txt_name.Text
            contact_no = txt_number.Text
            vehical_number = txt_v_no.Text
            vehical_model = txt_model.Text
            designation = txt_designation.Text

            rw.Item("User_name") = user_name
            rw.Item("Contact_number") = contact_no
            rw.Item("Vehicle_number") = vehical_number
            rw.Item("Vehicle_model") = vehical_model
            rw.Item("Rf_id") = Trim(Home.rf_id_check)
            rw.Item("Designation") = designation

            Try
                'DataRegisterUser1().Tables(0).Rows.Add(rw)
                Home.DataSetUser1().Tables(0).Rows.Add(rw)
                'Update the Student table in the testdb database.
                'i = OleDbregisterUserAdapter.Update(DataRegisterUser1)
                i = Home.OleDbDataUser.Update(Home.DataSetUser1())
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

            'Displays number of rows updated.
            If i > 0 Then
                MessageBox.Show("New User created succesfully.")
            End If
            Me.Close()
        End If
    End Sub

    Private Sub Txt_name_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_name.Leave
        'If Not A Matching format enterd
        If Not Regex.Match(Txt_name.Text, "^[a-z\s]*$", RegexOptions.IgnoreCase).Success Then 'only letters
            MessageBox.Show("Please Enter Alphabetic Characters Only!")
            Txt_name.Focus()
            Txt_name.Clear()
            NameValid = False
        Else
            NameValid = True
        End If
    End Sub

    Private Sub txt_model_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_model.Leave
        'If Not A Matching format enterd
        If Not Regex.Match(txt_model.Text, "^[a-zA-Z0-9\s]+$", RegexOptions.IgnoreCase).Success Then 'only letters
            MessageBox.Show("Please Enter Alphabetic Characters Only!")
            txt_model.Focus()
            txt_model.Clear()
            VehicleNameValid = False
        Else
            VehicleNameValid = True
        End If
    End Sub

    Private Sub txt_designation_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_designation.Leave
        If Not Regex.Match(txt_designation.Text, "^[a-zA-Z\s]+$", RegexOptions.IgnoreCase).Success Then 'only letters
            MessageBox.Show("Please Enter Alphabetic Characters Only!")
            txt_designation.Focus()
            txt_designation.Clear()
            DesignationValid = False
        Else
            DesignationValid = True
        End If
    End Sub

    Private Sub txt_number_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_number.Leave
        If Not Regex.Match(txt_number.Text, "^[7-9]\d{0}[0-9]\d{8}$", RegexOptions.IgnoreCase).Success Then 'only letters
            MessageBox.Show("Please Enter valid mobile number!")
            txt_number.Focus()
            txt_number.Clear()
            MobileValid = False
        Else
            MobileValid = True
        End If
    End Sub

    Private Sub txt_v_no_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_v_no.Leave
        If Not Regex.Match(txt_v_no.Text, "^[A-Z][A-Z]\d\d[A-Z][A-Z]\d\d\d\d", RegexOptions.IgnoreCase).Success Then 'only letters
            MessageBox.Show("Please Enter valid Vehicle number!")
            txt_v_no.Focus()
            txt_v_no.Clear()
            VehicleNoValid = False
        Else
            VehicleNoValid = True
        End If
    End Sub
End Class