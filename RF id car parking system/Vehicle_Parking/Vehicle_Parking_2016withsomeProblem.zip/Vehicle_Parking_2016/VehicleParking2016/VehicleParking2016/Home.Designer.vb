﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home))
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbEntry = New System.Data.OleDb.OleDbConnection()
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbAdapterEntry = New System.Data.OleDb.OleDbDataAdapter()
        Me.DataGridEntry = New System.Windows.Forms.DataGridView()
        Me.EntryidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RfidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntimeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OuttimeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VehicleEntryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataSetEntry1 = New VehicleParking2016.DataSetEntry()
        Me.OleDbSelectCommand2 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbUser = New System.Data.OleDb.OleDbConnection()
        Me.OleDbInsertCommand2 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbUpdateCommand2 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbDeleteCommand2 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbDataUser = New System.Data.OleDb.OleDbDataAdapter()
        Me.DataSetUser1 = New VehicleParking2016.DataSetUser()
        Me.Txt_charge = New System.Windows.Forms.TextBox()
        Me.lblcharg = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.parking = New System.Windows.Forms.TextBox()
        Me.btn_entery = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegisterUsersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReSetDatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OleDbSelectCommand3 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbSelectCommand4 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbInsertCommand3 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbUpdateCommand3 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbDeleteCommand3 = New System.Data.OleDb.OleDbCommand()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_rf_value = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.DataGridEntry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VehicleEntryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSetEntry1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSetUser1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT        Entry_id, Rf_id, In_time, Out_time, Parking_sloat" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "FROM            " & _
            "Vehicle_Entry"
        Me.OleDbSelectCommand1.Connection = Me.OleDbEntry
        '
        'OleDbEntry
        '
        Me.OleDbEntry.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\V_Parking_db.mdb;Per" & _
            "sist Security Info=True"
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO `Vehicle_Entry` (`Rf_id`, `In_time`, `Out_time`, `Parking_sloat`) VAL" & _
            "UES (?, ?, ?, ?)"
        Me.OleDbInsertCommand1.Connection = Me.OleDbEntry
        Me.OleDbInsertCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("Rf_id", System.Data.OleDb.OleDbType.VarWChar, 0, "Rf_id"), New System.Data.OleDb.OleDbParameter("In_time", System.Data.OleDb.OleDbType.[Date], 0, "In_time"), New System.Data.OleDb.OleDbParameter("Out_time", System.Data.OleDb.OleDbType.[Date], 0, "Out_time"), New System.Data.OleDb.OleDbParameter("Parking_sloat", System.Data.OleDb.OleDbType.VarWChar, 0, "Parking_sloat")})
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = resources.GetString("OleDbUpdateCommand1.CommandText")
        Me.OleDbUpdateCommand1.Connection = Me.OleDbEntry
        Me.OleDbUpdateCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("Rf_id", System.Data.OleDb.OleDbType.VarWChar, 0, "Rf_id"), New System.Data.OleDb.OleDbParameter("In_time", System.Data.OleDb.OleDbType.[Date], 0, "In_time"), New System.Data.OleDb.OleDbParameter("Out_time", System.Data.OleDb.OleDbType.[Date], 0, "Out_time"), New System.Data.OleDb.OleDbParameter("Parking_sloat", System.Data.OleDb.OleDbType.VarWChar, 0, "Parking_sloat"), New System.Data.OleDb.OleDbParameter("Original_Entry_id", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Entry_id", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Rf_id", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Rf_id", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Rf_id", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Rf_id", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_In_time", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "In_time", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_In_time", System.Data.OleDb.OleDbType.[Date], 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "In_time", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Out_time", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Out_time", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Out_time", System.Data.OleDb.OleDbType.[Date], 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Out_time", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Parking_sloat", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Parking_sloat", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Parking_sloat", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Parking_sloat", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = resources.GetString("OleDbDeleteCommand1.CommandText")
        Me.OleDbDeleteCommand1.Connection = Me.OleDbEntry
        Me.OleDbDeleteCommand1.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("Original_Entry_id", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Entry_id", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Rf_id", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Rf_id", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Rf_id", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Rf_id", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_In_time", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "In_time", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_In_time", System.Data.OleDb.OleDbType.[Date], 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "In_time", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Out_time", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Out_time", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Out_time", System.Data.OleDb.OleDbType.[Date], 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Out_time", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Parking_sloat", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Parking_sloat", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Parking_sloat", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Parking_sloat", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbAdapterEntry
        '
        Me.OleDbAdapterEntry.DeleteCommand = Me.OleDbDeleteCommand1
        Me.OleDbAdapterEntry.InsertCommand = Me.OleDbInsertCommand1
        Me.OleDbAdapterEntry.SelectCommand = Me.OleDbSelectCommand1
        Me.OleDbAdapterEntry.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Vehicle_Entry", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Entry_id", "Entry_id"), New System.Data.Common.DataColumnMapping("Rf_id", "Rf_id"), New System.Data.Common.DataColumnMapping("In_time", "In_time"), New System.Data.Common.DataColumnMapping("Out_time", "Out_time"), New System.Data.Common.DataColumnMapping("Parking_sloat", "Parking_sloat")})})
        Me.OleDbAdapterEntry.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'DataGridEntry
        '
        Me.DataGridEntry.AutoGenerateColumns = False
        Me.DataGridEntry.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridEntry.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.EntryidDataGridViewTextBoxColumn, Me.RfidDataGridViewTextBoxColumn, Me.IntimeDataGridViewTextBoxColumn, Me.OuttimeDataGridViewTextBoxColumn})
        Me.DataGridEntry.DataSource = Me.VehicleEntryBindingSource
        Me.DataGridEntry.Location = New System.Drawing.Point(40, 157)
        Me.DataGridEntry.Name = "DataGridEntry"
        Me.DataGridEntry.Size = New System.Drawing.Size(444, 176)
        Me.DataGridEntry.TabIndex = 0
        '
        'EntryidDataGridViewTextBoxColumn
        '
        Me.EntryidDataGridViewTextBoxColumn.DataPropertyName = "Entry_id"
        Me.EntryidDataGridViewTextBoxColumn.HeaderText = "Entry_id"
        Me.EntryidDataGridViewTextBoxColumn.Name = "EntryidDataGridViewTextBoxColumn"
        '
        'RfidDataGridViewTextBoxColumn
        '
        Me.RfidDataGridViewTextBoxColumn.DataPropertyName = "Rf_id"
        Me.RfidDataGridViewTextBoxColumn.HeaderText = "Rf_id"
        Me.RfidDataGridViewTextBoxColumn.Name = "RfidDataGridViewTextBoxColumn"
        '
        'IntimeDataGridViewTextBoxColumn
        '
        Me.IntimeDataGridViewTextBoxColumn.DataPropertyName = "In_time"
        Me.IntimeDataGridViewTextBoxColumn.HeaderText = "In_time"
        Me.IntimeDataGridViewTextBoxColumn.Name = "IntimeDataGridViewTextBoxColumn"
        '
        'OuttimeDataGridViewTextBoxColumn
        '
        Me.OuttimeDataGridViewTextBoxColumn.DataPropertyName = "Out_time"
        Me.OuttimeDataGridViewTextBoxColumn.HeaderText = "Out_time"
        Me.OuttimeDataGridViewTextBoxColumn.Name = "OuttimeDataGridViewTextBoxColumn"
        '
        'VehicleEntryBindingSource
        '
        Me.VehicleEntryBindingSource.DataMember = "Vehicle_Entry"
        Me.VehicleEntryBindingSource.DataSource = Me.DataSetEntry1
        '
        'DataSetEntry1
        '
        Me.DataSetEntry1.DataSetName = "DataSetEntry"
        Me.DataSetEntry1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OleDbSelectCommand2
        '
        Me.OleDbSelectCommand2.CommandText = "SELECT        User_name, User_id, Contact_number, Vehicle_number, Vehicle_model, " & _
            "Rf_id, Designation" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "FROM            Users"
        Me.OleDbSelectCommand2.Connection = Me.OleDbUser
        '
        'OleDbUser
        '
        Me.OleDbUser.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\V_Parking_db.mdb;Per" & _
            "sist Security Info=True"
        '
        'OleDbInsertCommand2
        '
        Me.OleDbInsertCommand2.CommandText = "INSERT INTO `Users` (`User_name`, `Contact_number`, `Vehicle_number`, `Vehicle_mo" & _
            "del`, `Rf_id`, `Designation`) VALUES (?, ?, ?, ?, ?, ?)"
        Me.OleDbInsertCommand2.Connection = Me.OleDbUser
        Me.OleDbInsertCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("User_name", System.Data.OleDb.OleDbType.VarWChar, 0, "User_name"), New System.Data.OleDb.OleDbParameter("Contact_number", System.Data.OleDb.OleDbType.LongVarWChar, 0, "Contact_number"), New System.Data.OleDb.OleDbParameter("Vehicle_number", System.Data.OleDb.OleDbType.VarWChar, 0, "Vehicle_number"), New System.Data.OleDb.OleDbParameter("Vehicle_model", System.Data.OleDb.OleDbType.VarWChar, 0, "Vehicle_model"), New System.Data.OleDb.OleDbParameter("Rf_id", System.Data.OleDb.OleDbType.VarWChar, 0, "Rf_id"), New System.Data.OleDb.OleDbParameter("Designation", System.Data.OleDb.OleDbType.VarWChar, 0, "Designation")})
        '
        'OleDbUpdateCommand2
        '
        Me.OleDbUpdateCommand2.CommandText = resources.GetString("OleDbUpdateCommand2.CommandText")
        Me.OleDbUpdateCommand2.Connection = Me.OleDbUser
        Me.OleDbUpdateCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("User_name", System.Data.OleDb.OleDbType.VarWChar, 0, "User_name"), New System.Data.OleDb.OleDbParameter("Contact_number", System.Data.OleDb.OleDbType.LongVarWChar, 0, "Contact_number"), New System.Data.OleDb.OleDbParameter("Vehicle_number", System.Data.OleDb.OleDbType.VarWChar, 0, "Vehicle_number"), New System.Data.OleDb.OleDbParameter("Vehicle_model", System.Data.OleDb.OleDbType.VarWChar, 0, "Vehicle_model"), New System.Data.OleDb.OleDbParameter("Rf_id", System.Data.OleDb.OleDbType.VarWChar, 0, "Rf_id"), New System.Data.OleDb.OleDbParameter("Designation", System.Data.OleDb.OleDbType.VarWChar, 0, "Designation"), New System.Data.OleDb.OleDbParameter("IsNull_User_name", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "User_name", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_User_name", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "User_name", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_User_id", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "User_id", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_User_id", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "User_id", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Vehicle_number", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Vehicle_number", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Vehicle_number", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Vehicle_number", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Vehicle_model", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Vehicle_model", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Vehicle_model", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Vehicle_model", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_Rf_id", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Rf_id", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Designation", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Designation", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Designation", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Designation", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbDeleteCommand2
        '
        Me.OleDbDeleteCommand2.CommandText = resources.GetString("OleDbDeleteCommand2.CommandText")
        Me.OleDbDeleteCommand2.Connection = Me.OleDbUser
        Me.OleDbDeleteCommand2.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("IsNull_User_name", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "User_name", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_User_name", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "User_name", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_User_id", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "User_id", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_User_id", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "User_id", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Vehicle_number", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Vehicle_number", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Vehicle_number", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Vehicle_number", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Vehicle_model", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Vehicle_model", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Vehicle_model", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Vehicle_model", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("Original_Rf_id", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Rf_id", System.Data.DataRowVersion.Original, Nothing), New System.Data.OleDb.OleDbParameter("IsNull_Designation", System.Data.OleDb.OleDbType.[Integer], 0, System.Data.ParameterDirection.Input, CType(0, Byte), CType(0, Byte), "Designation", System.Data.DataRowVersion.Original, True, Nothing), New System.Data.OleDb.OleDbParameter("Original_Designation", System.Data.OleDb.OleDbType.VarWChar, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Designation", System.Data.DataRowVersion.Original, Nothing)})
        '
        'OleDbDataUser
        '
        Me.OleDbDataUser.DeleteCommand = Me.OleDbDeleteCommand2
        Me.OleDbDataUser.InsertCommand = Me.OleDbInsertCommand2
        Me.OleDbDataUser.SelectCommand = Me.OleDbSelectCommand2
        Me.OleDbDataUser.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Users", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("User_name", "User_name"), New System.Data.Common.DataColumnMapping("User_id", "User_id"), New System.Data.Common.DataColumnMapping("Contact_number", "Contact_number"), New System.Data.Common.DataColumnMapping("Vehicle_number", "Vehicle_number"), New System.Data.Common.DataColumnMapping("Vehicle_model", "Vehicle_model"), New System.Data.Common.DataColumnMapping("Rf_id", "Rf_id"), New System.Data.Common.DataColumnMapping("Designation", "Designation")})})
        Me.OleDbDataUser.UpdateCommand = Me.OleDbUpdateCommand2
        '
        'DataSetUser1
        '
        Me.DataSetUser1.DataSetName = "DataSetUser"
        Me.DataSetUser1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Txt_charge
        '
        Me.Txt_charge.Location = New System.Drawing.Point(178, 68)
        Me.Txt_charge.Name = "Txt_charge"
        Me.Txt_charge.Size = New System.Drawing.Size(38, 20)
        Me.Txt_charge.TabIndex = 34
        Me.Txt_charge.Text = "2"
        '
        'lblcharg
        '
        Me.lblcharg.AutoSize = True
        Me.lblcharg.Location = New System.Drawing.Point(37, 71)
        Me.lblcharg.Name = "lblcharg"
        Me.lblcharg.Size = New System.Drawing.Size(67, 13)
        Me.lblcharg.TabIndex = 33
        Me.lblcharg.Text = "Parking Fare"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(53, 183)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Parking Sloat"
        Me.Label2.Visible = False
        '
        'parking
        '
        Me.parking.Location = New System.Drawing.Point(194, 180)
        Me.parking.Name = "parking"
        Me.parking.Size = New System.Drawing.Size(100, 20)
        Me.parking.TabIndex = 31
        Me.parking.Visible = False
        '
        'btn_entery
        '
        Me.btn_entery.Location = New System.Drawing.Point(118, 106)
        Me.btn_entery.Name = "btn_entery"
        Me.btn_entery.Size = New System.Drawing.Size(90, 23)
        Me.btn_entery.TabIndex = 30
        Me.btn_entery.Text = "Enter Vehicle"
        Me.btn_entery.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegisterUsersToolStripMenuItem, Me.ReSetDatabaseToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(536, 24)
        Me.MenuStrip1.TabIndex = 38
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegisterUsersToolStripMenuItem
        '
        Me.RegisterUsersToolStripMenuItem.Name = "RegisterUsersToolStripMenuItem"
        Me.RegisterUsersToolStripMenuItem.Size = New System.Drawing.Size(91, 20)
        Me.RegisterUsersToolStripMenuItem.Text = "Register users"
        '
        'ReSetDatabaseToolStripMenuItem
        '
        Me.ReSetDatabaseToolStripMenuItem.Name = "ReSetDatabaseToolStripMenuItem"
        Me.ReSetDatabaseToolStripMenuItem.Size = New System.Drawing.Size(98, 20)
        Me.ReSetDatabaseToolStripMenuItem.Text = "Reset Database"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 13)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Current RF Id"
        '
        'txt_rf_value
        '
        Me.txt_rf_value.Location = New System.Drawing.Point(178, 37)
        Me.txt_rf_value.Name = "txt_rf_value"
        Me.txt_rf_value.Size = New System.Drawing.Size(139, 20)
        Me.txt_rf_value.TabIndex = 41
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(222, 71)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 15)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "/ hr"
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(536, 356)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_rf_value)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Txt_charge)
        Me.Controls.Add(Me.lblcharg)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.parking)
        Me.Controls.Add(Me.btn_entery)
        Me.Controls.Add(Me.DataGridEntry)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Home"
        Me.Text = "Vehicle Parking"
        CType(Me.DataGridEntry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VehicleEntryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSetEntry1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSetUser1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbEntry As System.Data.OleDb.OleDbConnection
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbAdapterEntry As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents DataGridEntry As System.Windows.Forms.DataGridView
    Friend WithEvents VehicleEntryBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataSetEntry1 As VehicleParking2016.DataSetEntry
    Friend WithEvents OleDbSelectCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUser As System.Data.OleDb.OleDbConnection
    Friend WithEvents OleDbInsertCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDataUser As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents DataSetUser1 As VehicleParking2016.DataSetUser
    Friend WithEvents Txt_charge As System.Windows.Forms.TextBox
    Friend WithEvents lblcharg As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents parking As System.Windows.Forms.TextBox
    Friend WithEvents btn_entery As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents RegisterUsersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OleDbSelectCommand3 As System.Data.OleDb.OleDbCommand
    Friend WithEvents EntryidDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RfidDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntimeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OuttimeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OleDbSelectCommand4 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand3 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand3 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand3 As System.Data.OleDb.OleDbCommand
    Friend WithEvents ReSetDatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_rf_value As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label

End Class
