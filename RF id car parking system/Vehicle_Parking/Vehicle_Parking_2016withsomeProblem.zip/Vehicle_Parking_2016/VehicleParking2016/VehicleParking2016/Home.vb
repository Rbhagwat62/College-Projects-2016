﻿Imports System.IO.Ports
Imports System
Imports System.Text

Public Class Home
    Public Event DataReceived As SerialDataReceivedEventHandler
    Dim WithEvents mySerialport As SerialPort
    Dim myStringBuilder As New StringBuilder
    Dim rf_id As String
    Public rf_id_check As String
    Dim Rf_id_present, User_present As Boolean
    Dim com_port As String
    Public ds As DataSet

    Private Sub mySerialport_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles mySerialport.DataReceived
        myStringBuilder.Append(mySerialport.ReadExisting())
        Me.Invoke(New EventHandler(AddressOf UpdateControls))
    End Sub

    Private Sub UpdateControls(ByVal sender As Object, ByVal e As EventArgs)
        'Do any UI code here on the main thread
        'Me.txt_rf_value.Text = ""
        'Me.txt_rf_value.Text = myStringBuilder.ToString()
        rf_id = myStringBuilder.ToString()

        If String.IsNullOrEmpty(rf_id) <> True Then
            Dim rfid_string() As String = rf_id.Split(New String() {Environment.NewLine}, StringSplitOptions.None)

            If rfid_string.GetUpperBound(0) - 1 < 0 Then
                rf_id_check = ""
            Else
                rf_id_check = rfid_string(rfid_string.GetUpperBound(0) - 1)
                Me.txt_rf_value.Text = rf_id_check
            End If
        End If


        'If String.IsNullOrEmpty(rf_id) <> True Then
        '    Dim rfid_string() As String = rf_id.Split(New String() {Environment.NewLine}, StringSplitOptions.None)
        '    If String.IsNullOrWhiteSpace(rfid_string(rfid_string.GetUpperBound(0) - 1)) Then
        '        rf_id_check = ""
        '    Else
        '        rf_id_check = rfid_string(rfid_string.GetUpperBound(0) - 1)
        '    End If
        'End If
        
    End Sub
    Private Sub Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        OleDbAdapterEntry.Fill(DataSetEntry1)
        OleDbDataUser.Fill(DataSetUser1)
        com_port = InputBox("Enter COM Port to connect:")
        ds = DataSetUser1
        'MessageBox.Show(Lbl_Com_port.Text)
        If mySerialport Is Nothing Then
            Try
                mySerialport = My.Computer.Ports.OpenSerialPort(com_port, 57600, Parity.None, 8, StopBits.One)
                mySerialport.DtrEnable = True
                MessageBox.Show(com_port)
                mySerialport.WriteLine("hi")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            
        End If
    End Sub

    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        If mySerialport IsNot Nothing Then
            mySerialport.Close()
        End If

        'Me.Save()
    End Sub

    Private Sub btn_entery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_entery.Click
        Dim i, row, id As Integer
        Dim parking_sloat As String
        Dim in_time As DateTime
        Dim time As TimeSpan
        Dim rw As DataRow

        If String.IsNullOrWhiteSpace(rf_id_check) Then
            MessageBox.Show("Please Swap the card.")
        Else

            'DataSetUser1.Tables(0).AcceptChanges()
            'DataSetU.Reset()

            If (ds.Tables(0).Rows.Count - 1) = -1 Then
                User_present = False
                'MessageBox.Show("user not present")
            Else
                OleDbDataUser.Update(ds)
                For k = 0 To ds.Tables(0).Rows.Count - 1
                    'MessageBox.Show("for loop")
                    If String.Equals(rf_id_check, DataSetUser1.Tables(0).Rows(k).Item(5)) Then
                        User_present = True
                        'user_rw = DataSetUser1.Tables(0).NewRow
                        'user_rw = DataSetUser1.Tables(0).Rows(k)
                        'MessageBox.Show("user present")
                        Exit For
                    Else
                        User_present = False
                        'MessageBox.Show("user not present")
                    End If
                Next
            End If

            If User_present = True Then
                If (DataSetEntry1.Tables(0).Rows.Count - 1) = -1 Then
                    Rf_id_present = False
                Else
                    For j = 0 To DataSetEntry1.Tables(0).Rows.Count - 1
                        'Try
                        If String.Equals(Trim(rf_id_check), Trim(DataSetEntry1.Tables(0).Rows(j).Item(1))) Then
                            row = j
                            id = DataSetEntry1.Tables(0).Rows(j).Item(0)
                            in_time = DataSetEntry1.Tables(0).Rows(j).Item(2)

                            Rf_id_present = True
                            Exit For
                        Else
                            Rf_id_present = False
                        End If
                        'Catch ex As Exception
                        'MessageBox.Show(ex.Message)
                        'End Try
                    Next
                End If

                If Rf_id_present = True Then
                    Try
                        'Delete a row from the vehical table.
                        DataSetEntry1.Tables(0).Rows(row).Delete()

                        'Dim out = Date.Now()*
                        time = Date.Now().Subtract(in_time)
                        Dim charges As Double = Math.Round((((time.Days * 1440) + (time.Hours * 60) + time.Minutes) * (Val(Txt_charge.Text) / 60)), 2)
                        MessageBox.Show("One vehical out. And charges are : " + charges.ToString)
                        mySerialport.WriteLine("*")
                        'Update the vehical table in the database.
                        i = OleDbAdapterEntry.Update(DataSetEntry1)
                        OleDbAdapterEntry.Fill(DataSetEntry1)
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                ElseIf Rf_id_present = False Then
                    'Add a new row to the vehicle entry table.
                    rw = DataSetEntry1.Tables(0).NewRow
                    in_time = Date.Now()
                    parking_sloat = parking.Text
                    rw.Item("Rf_id") = Trim(rf_id_check)
                    rw.Item("In_time") = in_time
                    rw.Item("Parking_sloat") = parking_sloat
                    Try
                        DataSetEntry1().Tables(0).Rows.Add(rw)
                        mySerialport.WriteLine("#")
                        'Update the vehicle table in the database.
                        'i = OleDbAdapterEntry.Update(DataSetEntry1().Tables(0))
                        i = OleDbAdapterEntry.Update(DataSetEntry1)
                        'OleDbAdapterEntry.Fill(DataSetEntry1)
                    Catch ex As Exception
                        MessageBox.Show(ex.Message)
                    End Try
                    If i > 0 Then
                        MessageBox.Show("One vehical in.")
                    End If
                End If
            ElseIf User_present = False Then
                MessageBox.Show("User not present.")
                Registration_Form.Show()
            End If
            'If Rf_id_present = False Then
            '    'Add a new row to the vehicle entry table.
            '    rw = DataSetEntry1.Tables(0).NewRow
            '    in_time = Date.Now()
            '    parking_sloat = parking.Text
            '    rw.Item("Rf_id") = rf_id_check
            '    rw.Item("In_time") = in_time
            '    rw.Item("Parking_sloat") = parking_sloat
            '    Try
            '        DataSetEntry1().Tables(0).Rows.Add(rw)
            '        mySerialport.WriteLine("#")
            '        'Update the vehicle table in the database.
            '        i = OleDbAdapterEntry.Update(DataSetEntry1)
            '    Catch ex As Exception
            '        MessageBox.Show(ex.Message)
            '    End Try
            '    If i > 0 Then
            '        MessageBox.Show("One vehical in.")
            '    End If
            'End If
            'End If

            'If User_present = True Then
            '    If (DataSetEntry1.Tables(0).Rows.Count - 1) = -1 Then
            '        rw = DataSetEntry1.Tables(0).NewRow
            '        in_time = Date.Now()
            '        parking_sloat = parking.Text
            '        rw.Item("Rf_id") = rf_id_check
            '        rw.Item("In_time") = in_time
            '        rw.Item("Parking_sloat") = parking_sloat
            '        Try
            '            DataSetEntry1().Tables(0).Rows.Add(rw)
            '            mySerialport.WriteLine("#")
            '            i = OleDbAdapterEntry.Update(DataSetEntry1)
            '        Catch ex As Exception
            '            MessageBox.Show(ex.Message)
            '        End Try
            '        If i > 0 Then
            '            OleDbDataAdapter1.Fill(DataSet11)
            '            MessageBox.Show("One vehical in.")

            '        End If
            '    Else
            '        For k = 0 To DataSetEntry1.Tables(0).Rows.Count - 1
            '            If String.Equals(rf_id_check, DataSetEntry1.Tables(0).Rows(k).Item(1)) Then
            '                row = k
            '                id = DataSetEntry1.Tables(0).Rows(k).Item(0)
            '                in_time = DataSetEntry1.Tables(0).Rows(k).Item(2)

            '                Rf_id_present = True
            '                GoTo todo
            '            Else
            '                Rf_id_present = False
            '            End If
            '        Next
            '    End If
            'End If


            ''todo:
            ''        If Rf_id_present = True Then
            ''            Try
            ''                'Delete a row from the vehical table.
            ''                DataSetEntry1.Tables(0).Rows(row).Delete()
            ''                'Dim out = Date.Now()
            ''                time = Date.Now().Subtract(in_time)
            ''                MessageBox.Show("One vehical out. And charges are : " + (time.Minutes * (Val(Txt_charge.Text) / 60)).ToString)
            ''                mySerialport.WriteLine("*")
            ''                'Update the vehical table in the database.
            ''                i = OleDbAdapterEntry.Update(DataSetEntry1)
            ''            Catch ex As Exception
            ''                MsgBox(ex.Message)
            ''            End Try
            ''        End If
            ''End If
            'If User_present = False Then
            '    Registration_Form.Show()
            'End If
            ''End If
            ds = DataSetUser1
        End If
    End Sub

    'Private Sub BindingNavigatorDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VehicleDeleteItem.Click
    '    Try
    '        'Delete a row from the vehical table.
    '        DataSetEntry1.Tables(0).Rows(VehiclePositionItem.Selected).Delete()
    '        'Dim out = Date.Now()
    '        'Update the vehical table in the database.
    '        OleDbAdapterEntry.Update(DataSetEntry1)
    '        OleDbAdapterEntry.Fill(DataSetEntry1)
    '        DataGridEntry.DataSource = DataSetUser1.Tables(0)
    '    Catch ex As Exception
    '        MsgBox(ex.Message)
    '    End Try
    'End Sub

    Private Sub RegisterUsersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegisterUsersToolStripMenuItem.Click
        Register_user.Show()
    End Sub


    Private Sub btn_clear_rf_value_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        txt_rf_value.Clear()
        txt_rf_value.Text = ""
    End Sub

    Private Sub btn_reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ReSetDatabaseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReSetDatabaseToolStripMenuItem.Click
        If (DataSetEntry1.Tables(0).Rows.Count - 1) = -1 Then

        Else
            For k = 0 To DataSetEntry1.Tables(0).Rows.Count - 1
                Try
                    'Delete a row from the vehical table.
                    DataSetEntry1.Tables(0).Rows(k).Delete()
                    OleDbAdapterEntry.Update(DataSetEntry1)
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            Next
            'OleDbAdapterEntry.Update(DataSetEntry1)
            OleDbAdapterEntry.Fill(DataSetEntry1)
        End If
        If (ds.Tables(0).Rows.Count - 1) = -1 Then

        Else
            For k = 0 To ds.Tables(0).Rows.Count - 1
                Try
                    'Delete a row from the vehical table.
                    DataSetUser1.Tables(0).Rows(k).Delete()
                    OleDbDataUser.Update(DataSetUser1)
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            Next
            'OleDbDataUser.Update(DataSetUser1)
            OleDbDataUser.Fill(DataSetUser1)

        End If
    End Sub

End Class
