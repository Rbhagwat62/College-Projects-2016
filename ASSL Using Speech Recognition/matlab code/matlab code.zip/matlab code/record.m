  y=wavrecord(24000,8000);
 wavplay(y,8000);
 recsave;